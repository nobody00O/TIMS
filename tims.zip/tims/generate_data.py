import pandas as pd
import numpy as np
from datetime import datetime, timedelta

np.random.seed(42)

def make_data(n_points=1000):
    rows = []
    start = datetime.now() - timedelta(days=30)
    poi_list = [
        {"id":"POI_1","lat":28.7041,"lon":77.1025},
        {"id":"POI_2","lat":26.9124,"lon":75.7873},
        {"id":"POI_3","lat":27.1767,"lon":78.0081}
    ]
    for i in range(n_points):
        ts = start + timedelta(minutes=30*i)
        poi = np.random.choice(poi_list)

        hour = ts.hour
        dow = ts.weekday()
        temp = 15 + 10*np.sin(2*np.pi*(hour/24)) + np.random.randn()*2
        is_holiday = 1 if np.random.rand() < 0.05 else 0
        sentiment = np.random.uniform(-1,1)

        base = 50 + 30*(np.cos((hour-14)/6)) + 100*(1 - abs(sentiment))
        count = max(0, int(base + 20*np.random.randn() + is_holiday*50 - dow*2))

        rows.append({
            "timestamp": ts,
            "poi_id": poi["id"],
            "lat": poi["lat"],
            "lon": poi["lon"],
            "hour": hour,
            "dow": dow,
            "temp": round(temp,2),
            "is_holiday": is_holiday,
            "sentiment": round(sentiment,3),
            "visitors": count
        })

    df = pd.DataFrame(rows)
    return df

if __name__ == "__main__":
    df = make_data(1500)
    df.to_csv("tims_data.csv", index=False)
    print("Saved tims_data.csv (rows = {})".format(len(df)))
