from flask import Flask, request, jsonify, send_from_directory
import pandas as pd
import joblib
from datetime import datetime

app = Flask(__name__, static_folder="static", static_url_path="/static")
model = joblib.load("model.pkl")

live_store = []

@app.route("/")
def root():
    return send_from_directory("static", "index.html")

@app.route("/api/ingest", methods=["POST"])
def ingest():
    data = request.get_json()
    if not data:
        return jsonify({"error": "no json"}), 400

    data["timestamp"] = data.get("timestamp", datetime.utcnow().isoformat())
    live_store.append(data)

    return jsonify({"status": "ok", "stored": len(live_store)})

@app.route("/api/predict", methods=["POST"])
def predict():
    payload = request.get_json()
    if not payload:
        return jsonify({"error": "no json"}), 400

    rows = payload if isinstance(payload, list) else [payload]
    preds = []

    for r in rows:
        hour = r.get("hour", datetime.fromisoformat(r["timestamp"]).hour)
        dow = r.get("dow", datetime.fromisoformat(r["timestamp"]).weekday())
        temp = r.get("temp", 25.0)
        is_holiday = int(r.get("is_holiday", 0))
        sentiment = float(r.get("sentiment", 0.0))

        X = [[hour, dow, temp, is_holiday, sentiment]]
        p = model.predict(X)[0]

        preds.append({
            "poi_id": r.get("poi_id", "unknown"),
            "predicted_visitors": max(0, int(p))
        })

    return jsonify(preds)

@app.route("/api/live", methods=["GET"])
def api_live():
    return jsonify(live_store[-100:])

@app.route("/api/kpis", methods=["GET"])
def kpis():
    df = pd.DataFrame(live_store)
    if df.empty:
        return jsonify({"total_points": 0})

    total = len(df)
    avg_visitors = int(df["visitors"].dropna().mean()) if "visitors" in df else 0
    last = df.iloc[-1].to_dict()

    return jsonify({
        "total_points": total,
        "avg_visitors": avg_visitors,
        "last_point": last
    })

if __name__ == "__main__":
    print("TIMS API running: http://127.0.0.1:5000")
    app.run(debug=True)
